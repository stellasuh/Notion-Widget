window.onload = function() {
    const quotes = [
        {
            text: "“Many people are afraid to take challenge because they don’t know what they can do but i want to tell them that a new door can be open if they want to to try it. \nI’m always cheering for you” ",
            author: "W˙ᵕ˙",
            image: "https://i.pinimg.com/736x/d3/02/46/d30246bb4d5752db25bdeb916a76c425.jpg"
        },
        {
            text: "“Life will always be filled with stressful moments, but you can always choose to see something positive through it all.\nIt’ll be okay. You’ll be okay.”",
            author: "Joshua",
            image: "https://i.pinimg.com/736x/a4/10/ca/a410caee75a163fcac8e4c87d3dcecc8.jpg"
        },
        {
            text: "“Reality is more cruel than our imagination. But we are stronger than the person we imagine ourselves to be.”",
            author: "The8",
            image: "https://i.pinimg.com/736x/20/d9/2b/20d92b709c6fcb4698039935d011d753.jpg"
        },
        {
            text: "“When you focus on the good, the good gets better\n focus on the and you'll be happier.”",
            author: "Anonymous",
            image: "https://i.pinimg.com/1200x/d1/e8/84/d1e884fc1a06ffc1f29c22e0b8c1f11b.jpg"
        },
        {
            text: "“You don't need to have it all figured out, just take the next step.\n Allah is with you.”",
            author: "Anonymous",
            image: "https://i.pinimg.com/736x/2e/37/a1/2e37a10c3791bc5f67ea77b0bd1133f3.jpg"
        },
        {
            text: "“Even though it’s difficult sometimes, not knowing what you want to be is a privilege. Don’t feel bad about it. The most wonderful thing is being open.\nBeing a permanent student at heart.”",
            author: "Anonymous",
            image: "https://i.pinimg.com/736x/68/37/02/683702ef096b6bee886f11e0b7c2d63c.jpg"
        }
    ];

    const colors = ["#e66a8e", "#ecadc8", "#e98dad", "#ffbdd0"];
    let lastIndex = -1;  // To track the last shown quote

    // Function to get a random index, making sure it's not the same as the last index
    function getRandomIndex(arrLength, currentIndex) {
        let randomIndex;
        do {
            randomIndex = Math.floor(Math.random() * arrLength);
        } while (randomIndex === currentIndex); // Avoid repeating the same quote
        return randomIndex;
    }

    // Function to update the quote, author, image, and background color
    function updateQuote() {
        const randomIndex = getRandomIndex(quotes.length, lastIndex);
        lastIndex = randomIndex;

        const randomQuote = quotes[randomIndex];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];

        // Update quote, author, image, and background color
        document.getElementById('quoteDisplay').innerText = randomQuote.text;
        document.getElementById('authorDisplay').innerText = "- " + randomQuote.author;
        document.getElementById('quoteImage').src = randomQuote.image;
        document.getElementById('quoteContainer').style.backgroundColor = randomColor;
    }

    // Change quote every 5 seconds (5000 ms)
    setInterval(updateQuote, 10000);

    // Initial quote display
    updateQuote();
};